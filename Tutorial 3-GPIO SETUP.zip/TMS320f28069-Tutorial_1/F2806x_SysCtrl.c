//###########################################################################
//
// FILE:   F2806x_SysCtrl.c
//
// TITLE:  F2806x Device System Control Initialization & Support Functions.
//
// DESCRIPTION:
//
//         Example initialization of system resources.
//
//###########################################################################
// $TI Release: F2806x Support Library v2.04.00.00 $
// $Release Date: Mon May 27 06:46:38 CDT 2019 $
// $Copyright:
// Copyright (C) 2009-2019 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//
// Included Files
//
#include "F2806x_Device.h"     // Headerfile Include File
#include "F2806x_Examples.h"   // Examples Include File

//
// Functions that will be run from RAM need to be assigned to
// a different section.  This section will then be mapped to a load and
// run address using the linker cmd file.
//
//  *IMPORTANT*
//  IF RUNNING FROM FLASH, PLEASE COPY OVER THE SECTION "ramfuncs"  FROM FLASH
//  TO RAM PRIOR TO CALLING InitSysCtrl(). THIS PREVENTS THE MCU FROM THROWING 
//  AN EXCEPTION WHEN A CALL TO DELAY_US() IS MADE. 
//
#pragma CODE_SECTION(InitFlash, "ramfuncs");

//
// InitSysCtrl - This function initializes the System Control registers to a 
// known state.
// - Disables the watchdog
// - Set the PLLCR for proper SYSCLKOUT frequency
// - Set the pre-scaler for the high and low frequency peripheral clocks
// - Enable the clocks to the peripherals
//
void
InitSysCtrl(void)
{
    //
    // Disable the watchdog
    //
    DisableDog();

    //
    // *IMPORTANT*
    // The Device_cal function, which copies the ADC & oscillator calibration 
    // values from TI reserved OTP into the appropriate trim registers, occurs 
    // automatically in the Boot ROM. If the boot ROM code is bypassed during 
    // the debug process, the following function MUST be called for the ADC and
    // oscillators to function according to specification. The clocks to the 
    // ADC MUST be enabled before calling this function.
    // See the device data manual and/or the ADC Reference
    // Manual for more information.
    //
    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1; // Enable ADC peripheral clock
    (*Device_cal)();
    SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 0; // Return ADC clock to original state
    EDIS;

    //
    // Select Internal Oscillator 1 as Clock Source (default), and turn off all
    // unused clocks to conserve power.
    //
    IntOsc1Sel();

    //
    // Initialize the PLL control: PLLCR and CLKINDIV
    // DSP28_PLLCR and DSP28_CLKINDIV are defined in F2806x_Examples.h
    //
    InitPll(DSP28_PLLCR,DSP28_DIVSEL);

    //
    // Initialize the peripheral clocks
    //
    InitPeripheralClocks();
}

//
// InitFlash - This function initializes the Flash Control registers for 
// operation at 90MHz.  If you are running slower flash wait states can be 
// lessened. Refer to the datasheet for propper flash wait state values.
//                   CAUTION
// This function MUST be executed out of RAM. Executing it
// out of OTP/Flash will yield unpredictable results
//
void
InitFlash(void)
{
    EALLOW;
    
    //
    // Enable Flash Pipeline mode to improve performance of code executed from 
    // Flash.
    //
    FlashRegs.FOPT.bit.ENPIPE = 1;

    //                CAUTION
    // Minimum waitstates required for the flash operating
    // at a given CPU rate must be characterized by TI.
    // Refer to the datasheet for the latest information.
    //
    
    //
    // Set the Paged Waitstate for the Flash
    //
    FlashRegs.FBANKWAIT.bit.PAGEWAIT = 3;

    //
    // Set the Random Waitstate for the Flash
    //
    FlashRegs.FBANKWAIT.bit.RANDWAIT = 3;

    //
    // Set the Waitstate for the OTP
    //
    FlashRegs.FOTPWAIT.bit.OTPWAIT = 5;

    //
    // CAUTION -  ONLY THE DEFAULT VALUE FOR THESE 2 REGISTERS SHOULD BE USED
    //
    FlashRegs.FSTDBYWAIT.bit.STDBYWAIT = 0x01FF;
    FlashRegs.FACTIVEWAIT.bit.ACTIVEWAIT = 0x01FF;
    EDIS;
 
    //
    // Force a pipeline flush to ensure that the write to the last register
    // configured occurs before returning.
    //
    __asm(" RPT #7 || NOP");
}

//
// ServiceDog - This function resets the watchdog timer. Enable this function 
// for using ServiceDog in the application
//
void
ServiceDog(void)
{
    EALLOW;
    SysCtrlRegs.WDKEY = 0x0055;
    SysCtrlRegs.WDKEY = 0x00AA;
    EDIS;
}

//
// DisableDog - This function disables the watchdog timer.
//
void
DisableDog(void)
{
    EALLOW;
    SysCtrlRegs.WDCR= 0x0068;
    EDIS;
}

//
// InitPll - This function initializes the PLLCR register.
//
void
InitPll(Uint16 val, Uint16 divsel)
{
    volatile Uint16 iVol;

    // Make sure the PLL is not running in limp mode
    if (SysCtrlRegs.PLLSTS.bit.MCLKSTS != 0)
    {
    EALLOW;
    // OSCCLKSRC1 failure detected. PLL running in limp mode.
    // Re-enable missing clock logic.
    SysCtrlRegs.PLLSTS.bit.MCLKCLR = 1;
    EDIS;
    // Replace this line with a call to an appropriate
    // SystemShutdown(); function.
    __asm("        ESTOP0");     // Uncomment for debugging purposes
    }

    // DIVSEL MUST be 0 before PLLCR can be changed from
    // 0x0000. It is set to 0 by an external reset XRSn
    // This puts us in 1/4
    if (SysCtrlRegs.PLLSTS.bit.DIVSEL != 0)
    {
    EALLOW;
    SysCtrlRegs.PLLSTS.bit.DIVSEL = 0;
    EDIS;
    }

    //
    // Change the PLLCR
    //
    if (SysCtrlRegs.PLLCR.bit.DIV != val)
    {
        EALLOW;
        
        //
        // Before setting PLLCR turn off missing clock detect logic
        //
        SysCtrlRegs.PLLSTS.bit.MCLKOFF = 1;
        SysCtrlRegs.PLLCR.bit.DIV = val;
        EDIS;
        
        //
        // Optional: Wait for PLL to lock.
        // During this time the CPU will switch to OSCCLK/2 until
        // the PLL is stable.  Once the PLL is stable the CPU will
        // switch to the new PLL value.
        //
        // This time-to-lock is monitored by a PLL lock counter.
        //
        // Code is not required to sit and wait for the PLL to lock.
        // However, if the code does anything that is timing critical,
        // and requires the correct clock be locked, then it is best to
        // wait until this switching has completed.
        //

        //
        // Wait for the PLL lock bit to be set.
        //

        //
        // The watchdog should be disabled before this loop, or fed within
        // the loop via ServiceDog().
        //
        
        //
        // Uncomment to disable the watchdog
        //
        DisableDog();

        while(SysCtrlRegs.PLLSTS.bit.PLLLOCKS != 1)
        {
            //
            // Uncomment to service the watchdog
            //
            //ServiceDog();
        }

        EALLOW;
        SysCtrlRegs.PLLSTS.bit.MCLKOFF = 0;
        EDIS;
    }

    //
    // If switching to 1/2
    //
    if((divsel == 1)||(divsel == 2))
    {
        EALLOW;
        SysCtrlRegs.PLLSTS.bit.DIVSEL = divsel;
        EDIS;
    }

    //
    // If switching to 1/1
    // * First go to 1/2 and let the power settle
    //   The time required will depend on the system, this is only an example
    // * Then switch to 1/1
    //
    if(divsel == 3)
    {
        EALLOW;
        SysCtrlRegs.PLLSTS.bit.DIVSEL = 2;
        DELAY_US(50L);
        SysCtrlRegs.PLLSTS.bit.DIVSEL = 3;
        EDIS;
    }
}

//
// InitPll2 - This function initializes the PLL2 registers.
//
void
InitPll2(Uint16 clksrc, Uint16 pllmult, Uint16 clkdiv)
{
    EALLOW;

    //
    // Check if SYSCLK2DIV2DIS is in /2 mode
    //
    if(DevEmuRegs.DEVICECNF.bit.SYSCLK2DIV2DIS != 0)
    {
        DevEmuRegs.DEVICECNF.bit.SYSCLK2DIV2DIS = 0;
    }

    //
    // Enable PLL2
    //
    SysCtrlRegs.PLL2CTL.bit.PLL2EN = 1;
    
    //
    // Select clock source for PLL2
    //
    SysCtrlRegs.PLL2CTL.bit.PLL2CLKSRCSEL = clksrc;
    
    //
    // Set PLL2 Multiplier
    //
    SysCtrlRegs.PLL2MULT.bit.PLL2MULT = pllmult;
    
    //
    // Wait for PLL to lock.
    // Uncomment to disable the watchdog
    //
    DisableDog();
    while(SysCtrlRegs.PLL2STS.bit.PLL2LOCKS!= 1)
    {
        //
        // Uncomment to service the watchdog
        //
        //ServiceDog();
    }

    //
    // Set System Clock 2 divider
    //
    DevEmuRegs.DEVICECNF.bit.SYSCLK2DIV2DIS = clkdiv;
    EDIS;
}

//
// InitPeripheralClocks - This function initializes the clocks to the 
// peripheral modules. First the high and low clock prescalers are set
// Second the clocks are enabled to each peripheral.
// To reduce power, leave clocks to unused peripherals disabled
//
// Note: If a peripherals clock is not enabled then you cannot
// read or write to the registers for that peripheral
//
void
InitPeripheralClocks(void)
{
    EALLOW;

    //
    // LOSPCP prescale register settings, normally it will be set to default 
    // values
    //

    //
    //GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 3;  // GPIO18 = XCLKOUT
    //
    SysCtrlRegs.LOSPCP.all = 0x0002;

    //
    // XCLKOUT to SYSCLKOUT ratio.  By default XCLKOUT = 1/4 SYSCLKOUT
    //
    SysCtrlRegs.XCLK.bit.XCLKOUTDIV=2;

    //
    // Peripheral clock enables set for the selected peripherals.
    // If you are not using a peripheral leave the clock off
    // to save on power.
    //
    // Note: not all peripherals are available on all F2806x derivates.
    // Refer to the datasheet for your particular device.
    //
    // This function is not written to be an example of efficient code.
    //
    SysCtrlRegs.PCLKCR1.bit.EPWM1ENCLK = 0;    // ePWM1
    SysCtrlRegs.PCLKCR1.bit.EPWM2ENCLK = 0;    // ePWM2
    SysCtrlRegs.PCLKCR1.bit.EPWM3ENCLK = 0;    // ePWM3
    SysCtrlRegs.PCLKCR1.bit.EPWM4ENCLK = 0;    // ePWM4
    SysCtrlRegs.PCLKCR1.bit.EPWM5ENCLK = 0;    // ePWM5
    SysCtrlRegs.PCLKCR1.bit.EPWM6ENCLK = 0;    // ePWM6
    SysCtrlRegs.PCLKCR1.bit.EPWM7ENCLK = 0;    // ePWM7
    SysCtrlRegs.PCLKCR1.bit.EPWM8ENCLK = 0;    // ePWM8

    SysCtrlRegs.PCLKCR0.bit.HRPWMENCLK = 0;    // HRPWM
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;     // Enable TBCLK within the ePWM

    SysCtrlRegs.PCLKCR1.bit.EQEP1ENCLK =0;    // eQEP1
    SysCtrlRegs.PCLKCR1.bit.EQEP2ENCLK = 0;    // eQEP2

    SysCtrlRegs.PCLKCR1.bit.ECAP1ENCLK = 0;    // eCAP1
    SysCtrlRegs.PCLKCR1.bit.ECAP2ENCLK = 0;    // eCAP2
    SysCtrlRegs.PCLKCR1.bit.ECAP3ENCLK = 0;    // eCAP3

    SysCtrlRegs.PCLKCR2.bit.HRCAP1ENCLK = 0;   // HRCAP1
    SysCtrlRegs.PCLKCR2.bit.HRCAP2ENCLK = 0;   // HRCAP2
    SysCtrlRegs.PCLKCR2.bit.HRCAP3ENCLK = 0;   // HRCAP3
    SysCtrlRegs.PCLKCR2.bit.HRCAP4ENCLK = 0;   // HRCAP4

    SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 0;      // ADC
    SysCtrlRegs.PCLKCR3.bit.COMP1ENCLK = 0;    // COMP1
    SysCtrlRegs.PCLKCR3.bit.COMP2ENCLK = 0;    // COMP2
    SysCtrlRegs.PCLKCR3.bit.COMP3ENCLK = 0;    // COMP3

    SysCtrlRegs.PCLKCR3.bit.CPUTIMER0ENCLK = 1; // CPU Timer 0
    SysCtrlRegs.PCLKCR3.bit.CPUTIMER1ENCLK = 0; // CPU Timer 1
    SysCtrlRegs.PCLKCR3.bit.CPUTIMER2ENCLK = 0; // CPU Timer 2

    SysCtrlRegs.PCLKCR3.bit.DMAENCLK = 0;      // DMA

    SysCtrlRegs.PCLKCR3.bit.CLA1ENCLK = 0;     // CLA1

    SysCtrlRegs.PCLKCR3.bit.USB0ENCLK = 0;	   // USB0

    SysCtrlRegs.PCLKCR0.bit.I2CAENCLK = 0;     // I2C-A
    SysCtrlRegs.PCLKCR0.bit.SPIAENCLK = 0;     // SPI-A
    SysCtrlRegs.PCLKCR0.bit.SPIBENCLK = 0;     // SPI-B
    SysCtrlRegs.PCLKCR0.bit.SCIAENCLK = 0;     // SCI-A
    SysCtrlRegs.PCLKCR0.bit.SCIBENCLK = 0;     // SCI-B
    SysCtrlRegs.PCLKCR0.bit.MCBSPAENCLK = 0;   // McBSP-A
    SysCtrlRegs.PCLKCR0.bit.ECANAENCLK=0;      // eCAN-A

    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;     // Enable TBCLK within the ePWM




//--------------------------------------------------------------------------------------
// GPIO (GENERAL PURPOSE I/O) CONFIG
//--------------------------------------------------------------------------------------
//-----------------------
// QUICK NOTES on USAGE:
//-----------------------
// If GpioCtrlRegs.GP?MUX?bit.GPIO?= 1, 2 or 3 (i.e. Non GPIO func), then leave
//  rest of lines commented
// If GpioCtrlRegs.GP?MUX?bit.GPIO?= 0 (i.e. GPIO func), then:
//  1) uncomment GpioCtrlRegs.GP?DIR.bit.GPIO? = ? and choose pin to be IN or OUT
//  2) If IN, can leave next to lines commented
//  3) If OUT, uncomment line with ..GPACLEAR.. to force pin LOW or
//             uncomment line with ..GPASET.. to force pin HIGH or
//--------------------------------------------------------------------------------------
// Configure GPIO 0 to 9
//--------------------------------------------------------------------------------------
//  GPIO-00 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0;         // 0=GPIO,  1=EPWM1A,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO0 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO0 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-01 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0;         // 0=GPIO,  1=EPWM1B,  2=Resv,  3=COMP1OUT
    //GpioCtrlRegs.GPADIR.bit.GPIO1 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO1 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO1 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-02 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0;         // 0=GPIO,  1=EPWM2A,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO2 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO2 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO2 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-03 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0;         // 0=GPIO,  1=EPWM2B,  2=SPISOMI-A,  3=COMP2OUT
    //GpioCtrlRegs.GPADIR.bit.GPIO3 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO3 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO3 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-04 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 0;         // 0=GPIO,  1=EPWM3A,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO4 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO4 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO4 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-05 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 0;         // 0=GPIO,  1=EPWM3B,  2=SPISIMO-A,  3=ECAP1
    //GpioCtrlRegs.GPADIR.bit.GPIO5 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO5 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO5 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-06 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 0;         // 0=GPIO,  1=EPWM4A,  2=SYNCI,  3=SYNCO
    //GpioCtrlRegs.GPADIR.bit.GPIO6 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO6 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO6 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-07 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 0;         // 0=GPIO,  1=EPWM4B,  2=SCIRX-A,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO7 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO7 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO7 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-08 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 0;         // 0=GPIO,  1=EPWM5A,  2=Resv,  3=ADCSOC-A
    //GpioCtrlRegs.GPADIR.bit.GPIO8 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO8 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO8 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-09 - PIN FUNCTION
    //GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 0;         // 0=GPIO,  1=EPWM5B,  2=LINTX-A,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO9 = 1;          // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO9 = 1;    // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO9 = 1;      // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-10 - PIN FUNCTION = = PWM6A
    //GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 0;    // 0=GPIO,  1=EPWM6A,  2=Resv,  3=ADCSOC-B
    //GpioCtrlRegs.GPADIR.bit.GPIO10 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO10 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO10 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-11 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 0;    // 0=GPIO,  1=EPWM6B,  2=LINRX-A,  3=Resv
    //GpioCtrlRegs.GPADIR.bit.GPIO11 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO11 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO11 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-12 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 0;    // 0=GPIO,  1=TZ1,  2=SCITX-A,  3=SPISIMO-B
    //GpioCtrlRegs.GPADIR.bit.GPIO12 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO12 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO12 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-13 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 0;    // 0=GPIO,  1=TZ2,  2=Resv,  3=SPISOMI-B
    //GpioCtrlRegs.GPADIR.bit.GPIO13 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO13 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO13 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-14 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 0;    // 0=GPIO,  1=TZ3,  2=LINTX-A,  3=SPICLK-B
    //GpioCtrlRegs.GPADIR.bit.GPIO14 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO14 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO14 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-15 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 0;    // 0=GPIO,  1=TZ1,  2=LINRX-A,  3=SPISTE-B
    //GpioCtrlRegs.GPADIR.bit.GPIO15 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO15 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO15 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//  GPIO-16 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 0;    // 0=GPIO,  1=SPISIMO-A,  2=Resv,  3=TZ2
    //GpioCtrlRegs.GPADIR.bit.GPIO16 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO16 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO16 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-17 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 0;    // 0=GPIO,  1=SPISOMI-A,  2=Resv,  3=TZ3
    //GpioCtrlRegs.GPADIR.bit.GPIO17 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO17 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO17 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-18 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 0;    // 0=GPIO,  1=SPICLK-A,  2=LINTX-A,  3=XCLKOUT
    //GpioCtrlRegs.GPADIR.bit.GPIO18 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO18 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-19 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 0;    // 0=GPIO,  1=SPISTE-A,  2=LINRX-A,  3=ECAP1
    //GpioCtrlRegs.GPADIR.bit.GPIO19 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO19 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-20 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO20 = 0;    // 0=GPIO,  1=EQEPA-1,  2=Resv,  3=COMP1OUT
    //GpioCtrlRegs.GPADIR.bit.GPIO20 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO20 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-21 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO21 = 0;    // 0=GPIO,  1=EQEPB-1,  2=Resv,  3=COMP2OUT
    //GpioCtrlRegs.GPADIR.bit.GPIO21 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO21 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO21 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-22 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO22 = 0;    // 0=GPIO,  1=EQEPS-1,  2=Resv,  3=LINTX-A
    //GpioCtrlRegs.GPADIR.bit.GPIO22 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO22 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO22 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-23 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 0;    // 0=GPIO,  1=EQEPI-1,  2=Resv,  3=LINRX-A
    //GpioCtrlRegs.GPADIR.bit.GPIO23 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO23 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO23 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-24 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 0;    // 0=GPIO,  1=ECAP1,  2=Resv,  3=SPISIMO-B
    //GpioCtrlRegs.GPADIR.bit.GPIO24 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO24 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO24 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-25 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=SPISOMI-B
    //GpioCtrlRegs.GPADIR.bit.GPIO25 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO25 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO25 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-26 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=SPICLK-B
    //GpioCtrlRegs.GPADIR.bit.GPIO26 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO26 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO26 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-27 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=SPISTE-B
    //GpioCtrlRegs.GPADIR.bit.GPIO27 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO27 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-28 - PIN FUNCTION = SCI-RX
    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;    // 0=GPIO,  1=SCIRX-A,  2=I2CSDA-A,  3=TZ2
//  GpioCtrlRegs.GPADIR.bit.GPIO28 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO28 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO28 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-29 - PIN FUNCTION = SCI-TX
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;    // 0=GPIO,  1=SCITXD-A,  2=I2CSCL-A,  3=TZ3
//  GpioCtrlRegs.GPADIR.bit.GPIO29 = 0;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO29 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO29 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-30 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO30 = 1;    // 0=GPIO,  1=CANRX-A,  2=Resv,  3=Resv
//  GpioCtrlRegs.GPADIR.bit.GPIO30 = 0;       // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO30 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO30 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-31 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 1;    // 0=GPIO,  1=CANTX-A,  2=Resv,  3=Resv
//  GpioCtrlRegs.GPADIR.bit.GPIO31 = 1;       // 1=OUTput,  0=INput
//  GpioDataRegs.GPACLEAR.bit.GPIO31 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPASET.bit.GPIO31 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//  GPIO-32 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 0;    // 0=GPIO,  1=I2CSDA-A,  2=SYNCI,  3=ADCSOCA
    //GpioCtrlRegs.GPBDIR.bit.GPIO32 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO32 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-33 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 0;    // 0=GPIO,  1=I2CSCL-A,  2=SYNCO,  3=ADCSOCB
    //GpioCtrlRegs.GPBDIR.bit.GPIO33 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO33 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO33 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-34 - PIN FUNCTION = LED D9 on the F28069M LaunchPad
    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=Resv
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO34 = 0;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
// GPIO 35-38 are defaulted to JTAG usage, and are not shown here to enforce JTAG debug
// usage.
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//  GPIO-39 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO39 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO39 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO39 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-40 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO40 = 0;    // 0=GPIO,  1=EPWM7A,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO40 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO40 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO40 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-41 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO41 = 0;    // 0=GPIO,  1=EPWM7B,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO41 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO41 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO41 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-42 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=COMP1OUT
    //GpioCtrlRegs.GPBDIR.bit.GPIO42 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO42 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO42 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-43 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO43 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=COMP2OUT
    //GpioCtrlRegs.GPBDIR.bit.GPIO43 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO43 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO43 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-44 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX1.bit.GPIO44 = 0;    // 0=GPIO,  1=Resv,  2=Resv,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO44 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO44 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO44 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-50 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 0;    // 0=GPIO,  1=COMP2OUT,  2=EMU1,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO50 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//   GpioDataRegs.GPBSET.bit.GPIO37 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-51 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO51 = 0;    // 0=GPIO,  1=I2C-SDA,  2=SYNCI,  3=ADCSOCA
    //GpioCtrlRegs.GPBDIR.bit.GPIO51 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO32 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-52 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX2.bit.GPIO52 = 0;    // 0=GPIO,  1=I2C-SCL,  2=SYNCO,  3=ADCSOCB
    //GpioCtrlRegs.GPBDIR.bit.GPIO52 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO33 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO33 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-53 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO53 = 0;    // 0=GPIO,  1=COMP2OUT,  2=EMU1,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO53 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//    GpioDataRegs.GPBSET.bit.GPIO34 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-54 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO54 = 0;    // 0=GPIO,  1=COMP2OUT,  2=EMU1,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO54 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO37 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-55 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO55 = 0;    // 0=GPIO,  1=I2C-SDA,  2=SYNCI,  3=ADCSOCA
    //GpioCtrlRegs.GPBDIR.bit.GPIO55 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO32 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-56 - PIN FUNCTION = --Spare--
    //GpioCtrlRegs.GPBMUX2.bit.GPIO56 = 0;    // 0=GPIO,  1=I2C-SCL,  2=SYNCO,  3=ADCSOCB
    //GpioCtrlRegs.GPBDIR.bit.GPIO56 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO33 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO33 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-57 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO57 = 0;    // 0=GPIO,  1=COMP2OUT,  2=EMU1,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO57 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO34 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//  GPIO-58 - PIN FUNCTION = LED for F2806x USB dongle
    //GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 0;    // 0=GPIO,  1=COMP2OUT,  2=EMU1,  3=Resv
    //GpioCtrlRegs.GPBDIR.bit.GPIO58 = 1;     // 1=OUTput,  0=INput
//  GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;   // uncomment if --> Set Low initially
//  GpioDataRegs.GPBSET.bit.GPIO34 = 1;     // uncomment if --> Set High initially
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
    EDIS;
}

//
// CsmUnlock - This function unlocks the CSM. User must replace 0xFFFF's with 
// current password for the DSP. Returns 1 if unlock is successful.
//
#define STATUS_FAIL          0
#define STATUS_SUCCESS       1
Uint16
CsmUnlock()
{
    volatile Uint16 temp;

    //
    // Load the key registers with the current password. The 0xFFFF's are dummy
    // passwords.  User should replace them with the correct password for the 
    // DSP.
    //
    EALLOW;
    CsmRegs.KEY0 = 0xFFFF;
    CsmRegs.KEY1 = 0xFFFF;
    CsmRegs.KEY2 = 0xFFFF;
    CsmRegs.KEY3 = 0xFFFF;
    CsmRegs.KEY4 = 0xFFFF;
    CsmRegs.KEY5 = 0xFFFF;
    CsmRegs.KEY6 = 0xFFFF;
    CsmRegs.KEY7 = 0xFFFF;
    EDIS;

    //
    // Perform a dummy read of the password locations if they match the key 
    // values, the CSM will unlock
    //
    temp = CsmPwl.PSWD0;
    temp = CsmPwl.PSWD1;
    temp = CsmPwl.PSWD2;
    temp = CsmPwl.PSWD3;
    temp = CsmPwl.PSWD4;
    temp = CsmPwl.PSWD5;
    temp = CsmPwl.PSWD6;
    temp = CsmPwl.PSWD7;

    //
    // If the CSM unlocked, return succes, otherwise return
    // failure.
    //
    if (CsmRegs.CSMSCR.bit.SECURE == 0)
    {
        return STATUS_SUCCESS;
    }
    else
    {
        return STATUS_FAIL;
    }
}

//
// IntOsc1Sel - This function switches to Internal Oscillator 1 and turns off 
// all other clock sources to minimize power consumption
//
void
IntOsc1Sel(void)
{
    EALLOW;
    SysCtrlRegs.CLKCTL.bit.INTOSC1OFF = 0;
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRCSEL=0;  // Clk Src = INTOSC1
    SysCtrlRegs.CLKCTL.bit.XCLKINOFF=1;     // Turn off XCLKIN
    SysCtrlRegs.CLKCTL.bit.XTALOSCOFF=1;    // Turn off XTALOSC
    SysCtrlRegs.CLKCTL.bit.INTOSC2OFF=1;    // Turn off INTOSC2
    EDIS;
}

//
// IntOsc2Sel - This function switches to Internal oscillator 2 from External 
// Oscillator and turns off all other clock sources to minimize 
// power consumption
// NOTE: If there is no external clock connection, when switching from
//       INTOSC1 to INTOSC2, EXTOSC and XLCKIN must be turned OFF prior
//       to switching to internal oscillator 1
//
void
IntOsc2Sel(void)
{
    EALLOW;
    
    //
    // Errata Workaround - Toggle XCLKINOFF and XTALOSCOFF bits
    //
    SysCtrlRegs.CLKCTL.all |= 0x6000;
    SysCtrlRegs.CLKCTL.all &= ~0x6000;
    SysCtrlRegs.CLKCTL.all |= 0x6000;
    SysCtrlRegs.CLKCTL.all &= ~0x6000;    
    SysCtrlRegs.CLKCTL.all |= 0x6000;
    
    //
    // Turn on INTOSC2, set as source
    //
    SysCtrlRegs.CLKCTL.bit.INTOSC2OFF = 0;     // Turn on INTOSC2
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRC2SEL = 1;  // Select INTOSC2 as source
    
    //
    // Switch to use Internal Oscillator 2
    //
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRCSEL = 1;
    
    //
    // Clock Watchdog off of INTOSC1 always
    //
    SysCtrlRegs.CLKCTL.bit.WDCLKSRCSEL = 0;
    
    SysCtrlRegs.CLKCTL.bit.INTOSC1OFF = 0;     // Leave INTOSC1 on
    EDIS;
}

//
// XtalOscSel - This function switches to External CRYSTAL oscillator and turns
// off all other clock sources to minimize power consumption. This option may 
// not be available on all device packages
//
void
XtalOscSel(void)
{
    EALLOW;
    SysCtrlRegs.CLKCTL.bit.XTALOSCOFF = 0;     // Turn on XTALOSC
    
    //
    // Wait for 1ms while XTAL starts up
    //
    DELAY_US(1000);
    
    SysCtrlRegs.CLKCTL.bit.XCLKINOFF = 1;      // Turn off XCLKIN
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRC2SEL = 0;  // Switch to external clock
    
    //
    // Switch from INTOSC1 to INTOSC2/ext clk
    //
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRCSEL = 1;   
    
    //
    // Clock Watchdog off of INTOSC1 always
    //
    SysCtrlRegs.CLKCTL.bit.WDCLKSRCSEL = 0;
    
    SysCtrlRegs.CLKCTL.bit.INTOSC2OFF = 1;     // Turn off INTOSC2
    SysCtrlRegs.CLKCTL.bit.INTOSC1OFF = 0;     // Leave INTOSC1 on
    EDIS;
}

//
// ExtOscSel - This function switches to External oscillator and turns off all 
// other clock sources to minimize power consumption.
//
void
ExtOscSel(void)
{
    EALLOW;
    
    //
    // 1-GPIO19 = XCLKIN, 0-GPIO38 = XCLKIN
    //
    SysCtrlRegs.XCLK.bit.XCLKINSEL = 1;       
    
    SysCtrlRegs.CLKCTL.bit.XTALOSCOFF = 1;    // Turn on XTALOSC
    SysCtrlRegs.CLKCTL.bit.XCLKINOFF = 0;     // Turn on XCLKIN
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRC2SEL = 0; // Switch to external clock
    
    //
    // Switch from INTOSC1 to INTOSC2/ext clk
    //
    SysCtrlRegs.CLKCTL.bit.OSCCLKSRCSEL = 1;
    
    //
    // Clock Watchdog off of INTOSC1 always
    //
    SysCtrlRegs.CLKCTL.bit.WDCLKSRCSEL = 0;   
    
    SysCtrlRegs.CLKCTL.bit.INTOSC2OFF = 1;    // Turn off INTOSC2
    SysCtrlRegs.CLKCTL.bit.INTOSC1OFF = 0;    // Leave INTOSC1 on
    EDIS;
}

//
// End of File
//

