
#include "DSP28x_Project.h"     // DSP28x Headerfile
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
unsigned int success=0;
int main(void)
{

    InitSysCtrl();
#ifdef FLASH
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (uint32_t)&RamfuncsLoadSize);
    InitFlash();
#endif


    DINT;

    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    EINT;
    ERTM;
    while(success<=10){
        success++;
    }

	return 0;
}
