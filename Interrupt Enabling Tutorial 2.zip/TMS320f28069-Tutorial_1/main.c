//-----------------------------------------------------Header File Include Section--------------------------------------------------------------------
#include "DSP28x_Project.h"     // DSP28x Headerfile
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
//----------------------------------------------------Global Variable Declaration Section-------------------------------------------------------------
unsigned int success=0;
unsigned int timerstart=0;
//----------------------------------------------------Interrupt Prototype Declaration Section---------------------------------------------------------
__interrupt void cpu_timer0_isr(void);
//----------------------------------------------------------------------------------------------------------------------------------------------------
int main(void)
{

    InitSysCtrl();
#ifdef FLASH
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (uint32_t)&RamfuncsLoadSize);
    InitFlash();
#endif
//---------------------------------------------------Interrupt Initialization Section-------------------------------------------------------------------------------------------
    DINT;
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.TINT0 = &cpu_timer0_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
//---------------------------------------------------Peripheral Initialization Section------------------------------------------------------------------------------------------
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0,80,1000000);
    CpuTimer0Regs.TCR.all = 0x4000;
//---------------------------------------------------Interrupt Enable Section-------------------------------------==------------------------------------------------------------
    IER |= M_INT1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
    EINT;
    ERTM;
//---------------------------------------------------Main Program Section-------------------------------------------------------------------------------------------------------
    while(success<=10){
        success++;
    }

	return 0;
}

//---------------------------------------------------Interrupt Routine Section--------------------------------------------------------------------------------------------------
__interrupt void cpu_timer0_isr(void)
{
    CpuTimer0.InterruptCount++;
    timerstart++;
    if(timerstart>5){
        timerstart=0;
    }
    //
    // Acknowledge this interrupt to receive more interrupts from group 1
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
