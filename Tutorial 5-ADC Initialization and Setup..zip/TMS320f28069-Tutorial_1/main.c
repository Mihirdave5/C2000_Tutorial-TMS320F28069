//-----------------------------------------------------Header File Include Section--------------------------------------------------------------------
#include "DSP28x_Project.h"     // DSP28x Headerfile
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
//----------------------------------------------------Global Variable Declaration Section-------------------------------------------------------------
unsigned int success=0;
unsigned int timerstart=0;
Uint16 adcVoltage[5];
//----------------------------------------------------Interrupt Prototype Declaration Section---------------------------------------------------------
__interrupt void cpu_timer0_isr(void);
__interrupt void adc_isr(void);
//----------------------------------------------------Function Prototype Declaration------------------------------------------------------------------
void adcConfig(void);
void (*ptr)(void);
//----------------------------------------------------------------------------------------------------------------------------------------------------
int main(void)
{

    InitSysCtrl();
#ifdef FLASH
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (uint32_t)&RamfuncsLoadSize);
    InitFlash();
#endif
//---------------------------------------------------Interrupt Initialization Section-------------------------------------------------------------------------------------------
    DINT;
    InitPieCtrl();
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.TINT0 = &cpu_timer0_isr;
    PieVectTable.ADCINT1 = &adc_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
//---------------------------------------------------Peripheral Initialization Section------------------------------------------------------------------------------------------
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0,80,1000000);
    CpuTimer0Regs.TCR.all = 0x4000;
    InitAdc();  // For this example, init the ADC
    AdcOffsetSelfCal();
    (&adcConfig)();

//---------------------------------------------------Interrupt Enable Section-------------------------------------==------------------------------------------------------------

    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
    IER |= M_INT1;
    EINT;
    ERTM;
//---------------------------------------------------Main Program Section-------------------------------------------------------------------------------------------------------
    while(success<=10){
        success++;
    }

	return 0;
}

//---------------------------------------------------Interrupt Routine Section--------------------------------------------------------------------------------------------------
__interrupt void cpu_timer0_isr(void)
{
    CpuTimer0.InterruptCount++;
    timerstart++;
    if(timerstart>5){
        timerstart=0;
        GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;
    }
    //
    // Acknowledge this interrupt to receive more interrupts from group 1
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

__interrupt void adc_isr(void)
{
    adcVoltage[timerstart] = AdcResult.ADCRESULT0;
    //
    // Clear ADCINT1 flag reinitialize for next SOC
    //
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge interrupt to PIE

    return;
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void adcConfig(void){
    EALLOW;
    AdcRegs.ADCCTL1.bit.TEMPCONV    = 0;    //Connect internal temp sensor to channel ADCINA5.
    AdcRegs.ADCCTL2.bit.ADCNONOVERLAP = 1; // Enable non-overlap mode
    //
    // ADCINT1 trips after AdcResults latch
    //
    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdcRegs.INTSEL1N2.bit.INT1E     = 1;  // Enabled ADCINT1
    AdcRegs.INTSEL1N2.bit.INT1CONT  = 0;  // Disable ADCINT1 Continuous mode
    //
    // setup EOC1 to trigger ADCINT1 to fire
    //
    AdcRegs.INTSEL1N2.bit.INT1SEL   = 0;
    AdcRegs.ADCSOC0CTL.bit.CHSEL    = 0;  // set SOC0 channel select to ADCINA5
    AdcRegs.ADCSOC0CTL.bit.TRIGSEL  = 1;
    //
    // set SOC0 S/H Window to 7 ADC Clock Cycles, (6 ACQPS plus 1)
    //
    AdcRegs.ADCSOC0CTL.bit.ACQPS    = 8;
    EDIS;

}
